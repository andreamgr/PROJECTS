package tempconver;
import javax.swing.JFrame;
import tempconver.TemperatureConverterFrame;

public class TempConver1{
    public static void main(String[] args){
        TemperatureConverterFrame frame = new TemperatureConverterFrame();
    }
}
