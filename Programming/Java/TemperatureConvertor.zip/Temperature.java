 
 package tempconver;
 
 public class Temperature {
        private double celsius;
        private double farenheit;
    
        public Temperature() {
           setCelsius(0.0);
        }
        public void setCelsius (double c){
            this.celsius = c;
            this.farenheit = (c * 9.0/5.0) + 32; 
        }
        public void setFarenheit(double f){
            this.farenheit = f;
            this.celsius = (f - 32) * (5.0/9.0);
        }
        public double getCelsius(){
            return celsius;
        }
        public double getFarenheit(){
            return farenheit;
        }
    }