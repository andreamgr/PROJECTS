package tempconver;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.text.DecimalFormat;


public class TemperatureConverterFrame extends JFrame {

    //atributos

    private JTextField celsiusTxt;
    private JTextField farenheitTxt;
    private JLabel celsiusL;
    private JLabel farenheitL;
    private JButton rightB, leftB;
    private JPanel centerP, northP;
    private JLabel errorL;

    //constructor
   
    public TemperatureConverterFrame () {
        super ("Temperature Converter");
        //Configurar Frame
        setSize (450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Panel Norte 
        northP = new JPanel();
        celsiusL = new JLabel ("Celsius");
        farenheitL = new JLabel ("Fahrenheit");
        northP.add(celsiusL);
        northP.add(farenheitL);
        this.add(northP, BorderLayout.NORTH);

        //Panel del centro 
        centerP = new JPanel();
        celsiusTxt = new JTextField(10);
        farenheitTxt = new JTextField(10);
        rightB = new JButton (">");
        rightB.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e){
                if(!celsiusTxt.getText().isEmpty() ){
                    try{
                        double celsius = Double.parseDouble(celsiusTxt.getText());
                        Temperature temp = new Temperature();
                        temp.setCelsius(celsius);
                        DecimalFormat df = new DecimalFormat("#.##");
                        farenheitTxt.setText(df.format(temp.getFarenheit()));
                    }
                    catch(NumberFormatException nfe){
                        errorL.setText("Error: Not a number " + nfe.getLocalizedMessage());
                        JOptionPane.showMessageDialog(null, "Error: Not a number");
                    }
                }
            }
        });

        leftB = new JButton("<");
        leftB.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e){
                if(!farenheitTxt.getText().isEmpty() ){
                    try{
                        double farenheit = Double.parseDouble(farenheitTxt.getText());
                        //System.out.println("FARENHEIT: " + farenheit);
                        Temperature temp = new Temperature();
                        temp.setFarenheit(farenheit);
                        DecimalFormat df = new DecimalFormat("#.##");
                        celsiusTxt.setText(df.format(temp.getCelsius()));
                    }
                    catch(NumberFormatException nfe){
                        errorL.setText("Error: Not a number " + nfe.getLocalizedMessage());
                        JOptionPane.showMessageDialog(null, "Error: Not a number");
                    }
                }
                
            }
        });
        centerP.add(celsiusTxt);
        centerP.add(leftB);
        centerP.add(rightB);
        centerP.add(farenheitTxt);
        this.add(centerP, BorderLayout.CENTER);

        //panel del sur 
        errorL = new JLabel (" ");
        this.add(errorL, BorderLayout.SOUTH);
    
        //MOSTRAR FRAME 
        setVisible(true);
        

    }
    
    
}
